package StudentApplication.SpringJPAHibernate.Controllers;

import StudentApplication.SpringJPAHibernate.Model.User;
import StudentApplication.SpringJPAHibernate.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired

    UserRepository userRepoObj;
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return userRepoObj.findAll();

    }

    @DeleteMapping("/delete")
    public void deleteAll() {
        userRepoObj.deleteAll();
    }

}

